import AssignmentTracker from "./components/assignment-tracker"

export default function Home() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <AssignmentTracker />
    </main>
  )
}

