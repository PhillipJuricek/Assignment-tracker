import React from "react"
import { ResponsiveContainer, PieChart, Pie, Cell, Legend, Tooltip, BarChart, Bar, XAxis, YAxis } from "recharts"

interface DashboardProps {
  remainingTasks: number
  completedTasks: number
  classCompletionPercentages: { name: string; percentage: number }[]
}

export function Dashboard({ remainingTasks, completedTasks, classCompletionPercentages }: DashboardProps) {
  const data = [
    { name: "Remaining Tasks", value: remainingTasks },
    { name: "Completed Tasks", value: completedTasks },
  ]

  const totalTasks = remainingTasks + completedTasks
  const completionPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0

  const COLORS = ["#3730A3", "#6D28D9"]

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-2xl font-bold mb-4">Dashboard</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="md:col-span-2">
          <h3 className="text-lg font-semibold mb-2">Assignment Progress</h3>
          <p className="text-3xl font-bold">
            {completedTasks} / {totalTasks}
          </p>
          <p className="text-sm text-gray-500">Assignments completed</p>
          <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
            <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${completionPercentage}%` }}></div>
          </div>
          <p className="text-sm mt-1">{completionPercentage}% complete</p>
        </div>
        <div>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={data} cx="50%" cy="50%" labelLine={false} outerRadius={100} fill="#8884d8" dataKey="value">
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={classCompletionPercentages}>
              <XAxis dataKey="name" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="percentage" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}

