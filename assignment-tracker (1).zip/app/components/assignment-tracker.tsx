"use client"

import type React from "react"
import { useState, useMemo, useEffect } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import {
  MoreHorizontal,
  Edit2,
  Check,
  MessageSquare,
  LogIn,
  ChevronDown,
  ChevronUp,
  Upload,
  Trash2,
  Plus,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Dashboard } from "./dashboard"

type Priority = "low" | "medium" | "high"

interface Assignment {
  id: number
  class: string
  name: string
  weight: number
  dueDate: string
  completed: boolean
  priority: Priority
}

interface ClassInfo {
  name: string
  color: string
}

const priorityOpacity: Record<Priority, number> = {
  low: 0.3,
  medium: 0.6,
  high: 0.9,
}

const presetColors: Record<string, string> = {
  Red: "#FF6B6B",
  Blue: "#4ECDC4",
  Purple: "#9B59B6",
  Green: "#2ECC71",
  Yellow: "#F1C40F",
  Orange: "#E67E22",
  Pink: "#FF69B4",
  Teal: "#1ABC9C",
  Indigo: "#3498DB",
  Brown: "#D35400",
  Cyan: "#00CED1",
  Lime: "#32CD32",
  Maroon: "#800000",
  Navy: "#000080",
}

export default function AssignmentTracker() {
  const [assignments, setAssignments] = useState<Assignment[]>([])
  const [classes, setClasses] = useState<ClassInfo[]>([])
  const [newAssignment, setNewAssignment] = useState<Omit<Assignment, "id" | "completed">>({
    class: "",
    name: "",
    weight: 0,
    dueDate: "",
    priority: "medium",
  })
  const [newClass, setNewClass] = useState("")
  const [selectedColor, setSelectedColor] = useState(Object.keys(presetColors)[0])
  const [editingAssignment, setEditingAssignment] = useState<number | null>(null)
  const [showDashboard, setShowDashboard] = useState(true)
  const [showQuickAddClass, setShowQuickAddClass] = useState(true)
  const [editingClass, setEditingClass] = useState<string | null>(null)
  const [classToDelete, setClassToDelete] = useState<string | null>(null)
  const [editingClassName, setEditingClassName] = useState<string | null>(null)
  const [newClassName, setNewClassName] = useState("")

  const sortedAssignments = useMemo(() => {
    return [...assignments].sort((a, b) => {
      if (a.completed !== b.completed) {
        return a.completed ? 1 : -1
      }
      if (!a.completed && !b.completed) {
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
      }
      return 0
    })
  }, [assignments])

  const addAssignment = () => {
    if (newAssignment.class && newAssignment.name && newAssignment.dueDate) {
      setAssignments([...assignments, { ...newAssignment, id: Date.now(), completed: false }])
      setNewAssignment({ class: newAssignment.class, name: "", weight: 0, dueDate: "", priority: "medium" })
      if (!classes.some((c) => c.name === newAssignment.class)) {
        setClasses([...classes, { name: newAssignment.class, color: presetColors[selectedColor] }])
      }
    }
  }

  const updateAssignment = (id: number, field: keyof Assignment, value: string | number | boolean | Priority) => {
    setAssignments(
      assignments.map((assignment) => (assignment.id === id ? { ...assignment, [field]: value } : assignment)),
    )
  }

  const addClass = () => {
    if (newClass && !classes.some((c) => c.name === newClass)) {
      setClasses([...classes, { name: newClass, color: presetColors[selectedColor] }])
      setNewClass("")
      setSelectedColor(Object.keys(presetColors)[(classes.length + 1) % Object.keys(presetColors).length])
    }
  }

  const handleClassKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      addClass()
    }
  }

  const getClassColor = (className: string, priority: Priority, completed: boolean) => {
    if (completed) {
      return "#90EE90" // Light green color for completed assignments
    }
    const classInfo = classes.find((c) => c.name === className)
    const baseColor = classInfo ? classInfo.color : presetColors[Object.keys(presetColors)[0]]
    const opacity = priorityOpacity[priority]
    return `${baseColor}${Math.round((1 - opacity) * 255)
      .toString(16)
      .padStart(2, "0")}`
  }

  const calculateYearProgress = () => {
    const now = new Date()
    const start = new Date(now.getFullYear(), 0, 0)
    const diff = now.getTime() - start.getTime()
    const oneDay = 1000 * 60 * 60 * 24
    const day = Math.floor(diff / oneDay)
    return Math.round((day / 365) * 100)
  }

  const removeClass = (className: string) => {
    setClasses(classes.filter((c) => c.name !== className))
    setAssignments(assignments.filter((a) => a.class !== className))
  }

  const editClass = (oldName: string, newName: string, newColor: string) => {
    setClasses(classes.map((c) => (c.name === oldName ? { ...c, name: newName, color: newColor } : c)))
    setAssignments(assignments.map((a) => (a.class === oldName ? { ...a, class: newName } : a)))
    setEditingClassName(null)
  }

  const clearAllClasses = () => {
    setClasses([])
    setAssignments([])
  }

  const calculateClassCompletion = (className: string) => {
    const classAssignments = assignments.filter((a) => a.class === className)
    const totalWeight = classAssignments.reduce((sum, a) => sum + a.weight, 0)
    const completedWeight = classAssignments.filter((a) => a.completed).reduce((sum, a) => sum + a.weight, 0)

    // Normalize weights to ensure they add up to 100%
    const normalizedCompletedWeight = totalWeight > 0 ? (completedWeight / totalWeight) * 100 : 0

    return Math.round(normalizedCompletedWeight)
  }

  const startEditingClass = (className: string) => {
    setEditingClassName(className)
    setNewClassName(className)
  }

  const saveEditedClass = () => {
    if (editingClassName && newClassName) {
      editClass(
        editingClassName,
        newClassName,
        classes.find((c) => c.name === editingClassName)?.color || presetColors.Red,
      )
      setEditingClassName(null)
      setNewClassName("")
    }
  }

  const cancelEditingClass = () => {
    setEditingClassName(null)
    setNewClassName("")
  }

  // Add random classes and assignments for testing
  useEffect(() => {
    const randomClasses = [
      { name: "Math", color: presetColors.Red },
      { name: "Science", color: presetColors.Blue },
      { name: "History", color: presetColors.Green },
      { name: "English", color: presetColors.Purple },
      { name: "Art", color: presetColors.Yellow },
      { name: "Physics", color: presetColors.Orange },
      { name: "Chemistry", color: presetColors.Pink },
      { name: "Biology", color: presetColors.Teal },
      { name: "Computer Science", color: presetColors.Indigo },
      { name: "Physical Education", color: presetColors.Brown },
    ]

    const randomAssignments = [
      { class: "Math", name: "Algebra Quiz", weight: 10, dueDate: "2023-06-15", priority: "high" as Priority },
      { class: "Science", name: "Lab Report", weight: 15, dueDate: "2023-06-20", priority: "medium" as Priority },
      { class: "History", name: "Essay", weight: 20, dueDate: "2023-06-25", priority: "high" as Priority },
      { class: "English", name: "Book Review", weight: 10, dueDate: "2023-06-18", priority: "low" as Priority },
      { class: "Art", name: "Portfolio", weight: 25, dueDate: "2023-06-30", priority: "medium" as Priority },
      { class: "Math", name: "Final Exam", weight: 30, dueDate: "2023-07-05", priority: "high" as Priority },
      { class: "Science", name: "Research Paper", weight: 20, dueDate: "2023-07-10", priority: "medium" as Priority },
      { class: "History", name: "Presentation", weight: 15, dueDate: "2023-07-03", priority: "low" as Priority },
      { class: "English", name: "Poetry Analysis", weight: 10, dueDate: "2023-07-08", priority: "medium" as Priority },
      { class: "Art", name: "Exhibition", weight: 20, dueDate: "2023-07-15", priority: "high" as Priority },
      { class: "Physics", name: "Problem Set", weight: 15, dueDate: "2023-07-12", priority: "medium" as Priority },
      {
        class: "Chemistry",
        name: "Experiment Report",
        weight: 20,
        dueDate: "2023-07-18",
        priority: "high" as Priority,
      },
      { class: "Biology", name: "Term Paper", weight: 25, dueDate: "2023-07-22", priority: "high" as Priority },
      {
        class: "Computer Science",
        name: "Coding Project",
        weight: 30,
        dueDate: "2023-07-25",
        priority: "high" as Priority,
      },
      {
        class: "Physical Education",
        name: "Fitness Test",
        weight: 10,
        dueDate: "2023-07-28",
        priority: "low" as Priority,
      },
    ]

    setClasses(randomClasses)
    setAssignments(randomAssignments.map((a, index) => ({ ...a, id: index + 1, completed: false })))
  }, [])

  return (
    <div className="container mx-auto p-4 bg-gray-50 min-h-screen">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">UniTask</h1>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" onClick={() => alert("Import functionality to be implemented")}>
            <Upload className="w-4 h-4 mr-2" />
            Import
          </Button>
          <Button variant="outline" size="sm" onClick={() => alert("Feedback functionality to be implemented")}>
            <MessageSquare className="w-4 h-4 mr-2" />
            Feedback
          </Button>
          <Button variant="outline" size="sm" onClick={() => alert("Sign in functionality to be implemented")}>
            <LogIn className="w-4 h-4 mr-2" />
            Sign In
          </Button>
        </div>
      </div>

      <div className="flex justify-end mb-4">
        <Button onClick={() => setShowDashboard(!showDashboard)}>
          {showDashboard ? "Hide Dashboard" : "Show Dashboard"}
        </Button>
      </div>

      {showDashboard && (
        <Dashboard
          remainingTasks={assignments.filter((a) => !a.completed).length}
          completedTasks={assignments.filter((a) => a.completed).length}
          yearProgress={calculateYearProgress()}
          classCompletionPercentages={classes.map((cls) => ({
            name: cls.name,
            percentage: calculateClassCompletion(cls.name),
          }))}
        />
      )}

      <div className="bg-white p-4 rounded-lg shadow-md mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Quick Add Assignment</h2>
          <Button variant="ghost" size="sm" onClick={() => setShowQuickAddClass(!showQuickAddClass)} className="p-1">
            {showQuickAddClass ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </Button>
        </div>
        {showQuickAddClass && (
          <div className="mb-4">
            <h3 className="text-lg font-semibold mb-2">Quick Add Class</h3>
            <div className="flex gap-2 mb-2">
              <Input
                placeholder="New Class"
                value={newClass}
                onChange={(e) => setNewClass(e.target.value)}
                onKeyPress={handleClassKeyPress}
                className="flex-grow"
              />
              <Select value={selectedColor} onValueChange={setSelectedColor}>
                <SelectTrigger className="w-[100px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(presetColors).map(([name, color]) => (
                    <SelectItem key={name} value={name}>
                      <div className="flex items-center">
                        <div className="w-4 h-4 rounded-full mr-2" style={{ backgroundColor: color }}></div>
                        {name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Popover>
                <PopoverTrigger asChild>
                  <Button onClick={addClass}>Add Class</Button>
                </PopoverTrigger>
                <PopoverContent className="w-56" side="right" align="start">
                  <div className="space-y-2">
                    {classes.map((cls) => (
                      <div key={cls.name} className="flex items-center justify-between py-1">
                        <span>{cls.name}</span>
                        <div>
                          <Button variant="ghost" size="sm" onClick={() => startEditingClass(cls.name)}>
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => setClassToDelete(cls.name)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          </div>
        )}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <Select onValueChange={(value) => setNewAssignment({ ...newAssignment, class: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select Class" />
            </SelectTrigger>
            <SelectContent>
              {classes.map((cls) => (
                <SelectItem key={cls.name} value={cls.name}>
                  {cls.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input
            placeholder="Assignment"
            value={newAssignment.name}
            onChange={(e) => setNewAssignment({ ...newAssignment, name: e.target.value })}
          />
          <Input
            type="number"
            placeholder="Weight"
            value={newAssignment.weight === 0 ? "" : newAssignment.weight}
            onChange={(e) => setNewAssignment({ ...newAssignment, weight: Number(e.target.value) })}
          />
          <Input
            type="date"
            value={newAssignment.dueDate}
            onChange={(e) => setNewAssignment({ ...newAssignment, dueDate: e.target.value })}
            className="w-full"
          />
          <Select
            value={newAssignment.priority}
            onValueChange={(value: Priority) => setNewAssignment({ ...newAssignment, priority: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button onClick={addAssignment} className="mt-4 w-full">
          Add Assignment
        </Button>
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden max-w-5xl mx-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="font-semibold">Class</TableHead>
              <TableHead className="font-semibold">Assignment</TableHead>
              <TableHead className="font-semibold">Weight (%)</TableHead>
              <TableHead className="font-semibold">Due Date</TableHead>
              <TableHead className="font-semibold">Priority</TableHead>
              <TableHead className="font-semibold">Completed</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedAssignments.map((assignment) => (
              <TableRow
                key={assignment.id}
                className={cn(
                  "transition-all duration-300 group hover:bg-gray-50",
                  assignment.completed ? "bg-green-50" : "",
                )}
                style={{ backgroundColor: getClassColor(assignment.class, assignment.priority, assignment.completed) }}
              >
                <TableCell className="font-medium">{assignment.class}</TableCell>
                <TableCell className="font-bold">
                  {editingAssignment === assignment.id ? (
                    <Input
                      value={assignment.name}
                      onChange={(e) => updateAssignment(assignment.id, "name", e.target.value)}
                    />
                  ) : (
                    assignment.name
                  )}
                </TableCell>
                <TableCell className="font-bold">
                  {editingAssignment === assignment.id ? (
                    <Input
                      type="number"
                      value={assignment.weight === 0 ? "" : assignment.weight}
                      onChange={(e) => updateAssignment(assignment.id, "weight", Number(e.target.value))}
                      placeholder="Weight"
                    />
                  ) : (
                    assignment.weight
                  )}
                </TableCell>
                <TableCell className="font-bold">
                  {editingAssignment === assignment.id ? (
                    <Input
                      type="date"
                      value={assignment.dueDate}
                      onChange={(e) => updateAssignment(assignment.id, "dueDate", e.target.value)}
                      className="w-full"
                    />
                  ) : (
                    assignment.dueDate
                  )}
                </TableCell>
                <TableCell className="font-bold">
                  {editingAssignment === assignment.id ? (
                    <Select
                      value={assignment.priority}
                      onValueChange={(value: Priority) => updateAssignment(assignment.id, "priority", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    assignment.priority
                  )}
                </TableCell>
                <TableCell>
                  <div
                    className={`h-5 w-5 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${
                      assignment.completed ? "bg-green-500 border-green-500" : "border-gray-300"
                    }`}
                    onClick={() => updateAssignment(assignment.id, "completed", !assignment.completed)}
                  >
                    {assignment.completed && <Check className="h-3 w-3 text-white" />}
                  </div>
                </TableCell>
                <TableCell>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="ghost"
                        className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent align="end" className="w-[200px]">
                      <Button
                        variant="ghost"
                        onClick={() => setEditingAssignment(editingAssignment === assignment.id ? null : assignment.id)}
                        className="w-full justify-start"
                      >
                        <Edit2 className="mr-2 h-4 w-4" />
                        {editingAssignment === assignment.id ? "Save" : "Edit"}
                      </Button>
                    </PopoverContent>
                  </Popover>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      {classToDelete && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg">
            <p className="mb-4">
              Are you sure you would like to delete this class? Deleting this class will delete all associated
              assignments.
            </p>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setClassToDelete(null)}>
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={() => {
                  removeClass(classToDelete)
                  setClassToDelete(null)
                }}
              >
                Delete
              </Button>
            </div>
          </div>
        </div>
      )}
      {editingClassName && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-4">Edit Class Name</h3>
            <Input value={newClassName} onChange={(e) => setNewClassName(e.target.value)} className="mb-4" />
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={cancelEditingClass}>
                Cancel
              </Button>
              <Button onClick={saveEditedClass}>Save</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

